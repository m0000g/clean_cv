# Clean CV

Clean CV is a pretty basic cv with html + css + normalize.css

# Special thanks

- https://necolas.github.io/normalize.css/

# To do

- Add gallery fotos and links